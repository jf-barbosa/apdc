package pt.unl.fct.di.apdc.firstwebapp.resources;

import java.util.logging.Logger;

import javax.ws.rs.Consumes;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.EntityNotFoundException;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;

import pt.unl.fct.di.apdc.firstwebapp.util.UpdateData;
//import com.google.appengine.repackaged.org.apache.commons.codec.digest.DigestUtils;

@Path("/update")
public class UpdateResource {

	private static final Logger LOG = Logger.getLogger(RegisterResource.class.getName());
	private static final DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

	public UpdateResource() {

	}

	@PUT
	@Path("/")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON + ";chartset=utf-8")
	public Response update(UpdateData data) {

		try {
			Key userKey = KeyFactory.createKey("User", data.username);
			Entity user = datastore.get(userKey);
			user.setProperty("user_email", data.email);
			user.setProperty("user_phone", data.phone);
			user.setProperty("user_mobile", data.mobile);
			user.setProperty("user_address", data.address);
			user.setProperty("user_addressc", data.addressc);
			user.setProperty("user_localidade", data.localidade);
			user.setProperty("user_cp", data.cp);
			datastore.put(user);
			return Response.ok().build();
		} catch (EntityNotFoundException e) {


			return Response.status(Status.BAD_REQUEST).entity("User doesn't exists").build();

		}
	}
	
	@PUT
	@Path("/GBO")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON + ";chartset=utf-8")
	public Response updateGBO(UpdateData data) {

		try {
			Key userKey = KeyFactory.createKey("User", data.username);
			Entity user = datastore.get(userKey);
			user.setProperty("user_name", data.username);
			user.setProperty("user_email", data.email);
			user.setProperty("user_phone", data.phone);
			user.setProperty("user_mobile", data.mobile);
			user.setProperty("user_address", data.address);
			user.setProperty("user_addressc", data.addressc);
			user.setProperty("user_localidade", data.localidade);
			user.setProperty("user_cp", data.cp);
			datastore.put(user);
			return Response.ok().build();
		} catch (EntityNotFoundException e) {


			return Response.status(Status.BAD_REQUEST).entity("User doesn't exists").build();

		}
	}
	
	@PUT
	@Path("/role")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON + ";chartset=utf-8")
	public Response updateRole(UpdateData data) {

		try {
			Key userKey = KeyFactory.createKey("User", data.username);
			Entity user = datastore.get(userKey);
			user.setProperty("user_name", data.username);
			user.setProperty("user_role", "auser");
			
			datastore.put(user);
			return Response.ok().build();
		} catch (EntityNotFoundException e) {


			return Response.status(Status.BAD_REQUEST).entity("User doesn't exists").build();

		}
	}
}
