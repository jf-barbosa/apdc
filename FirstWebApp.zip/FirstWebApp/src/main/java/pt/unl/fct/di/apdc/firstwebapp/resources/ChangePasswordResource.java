package pt.unl.fct.di.apdc.firstwebapp.resources;



import javax.ws.rs.Consumes;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.apache.commons.codec.digest.DigestUtils;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.EntityNotFoundException;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;

import pt.unl.fct.di.apdc.firstwebapp.util.ChangePasswordData;

//import com.google.appengine.repackaged.org.apache.commons.codec.digest.DigestUtils;

@Path("/changeP")
public class ChangePasswordResource {

	private static final DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

	public ChangePasswordResource() {

	}

	@PUT
	@Path("/")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON + ";chartset=utf-8")
	public Response changePassword(ChangePasswordData data) {

		try {
			Key userKey = KeyFactory.createKey("User", data.username);
			Entity user = datastore.get(userKey);
			user.setProperty("user_name", data.username);
			user.setProperty("user_pwd",DigestUtils.sha512Hex(data.password));
			//user.setProperty("user_password",data.password);
			datastore.put(user);
			return Response.ok().build();
		} catch (EntityNotFoundException e) {


			return Response.status(Status.BAD_REQUEST).entity("User doesn't exists").build();

		}
	}
}

