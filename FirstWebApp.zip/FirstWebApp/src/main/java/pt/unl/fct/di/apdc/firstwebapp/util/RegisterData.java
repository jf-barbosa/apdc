package pt.unl.fct.di.apdc.firstwebapp.util;

public class RegisterData {

	public String username;
	public String password;
	public String email;
	public String mobile;
	public String phone;
	public String role;
	public String address;
	public String addressc;
	public String localidade;
	public String cp;
	public String type;
	
	public RegisterData() {
		
	}
	
	public RegisterData(String username, String password, String email, String role, String address,String localidade, String cp, String phone, String mobile, String addressc,String type) {
		this.username = username;
		this.email = email;
		this.role = role;
		this.password = password;
		this.mobile = mobile;
		this.phone = phone;
		this.address = address;
		this.addressc = addressc;
		this.localidade = localidade;
		this.cp = cp;
		this.type = type;
	}
}
