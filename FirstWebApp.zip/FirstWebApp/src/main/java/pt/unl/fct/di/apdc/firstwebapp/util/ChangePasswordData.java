package pt.unl.fct.di.apdc.firstwebapp.util;

public class ChangePasswordData {

	public String username;
	public String password;

	public ChangePasswordData() {

	}

	public ChangePasswordData(String username, String password) {
		this.username = username;
		this.password = password;
	}

}
