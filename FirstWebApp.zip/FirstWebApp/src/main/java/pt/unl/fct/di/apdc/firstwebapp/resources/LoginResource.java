package pt.unl.fct.di.apdc.firstwebapp.resources;

import java.util.logging.Logger;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.EntityNotFoundException;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import org.apache.commons.codec.digest.DigestUtils;

import pt.unl.fct.di.apdc.firstwebapp.util.AuthToken;
import pt.unl.fct.di.apdc.firstwebapp.util.LoginData;

@Path("/login")
@Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
public class LoginResource {
	/**
	 * A Logger Object
	 */
	private static final DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
	private static final Logger LOG = Logger.getLogger(LoginResource.class.getName());

	public LoginResource() {
	}

	@POST
	@Path("/")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response doLogin(LoginData data) {

		try {
			Key userKey = KeyFactory.createKey("User", data.username);
			Entity user = datastore.get(userKey);
			if (DigestUtils.sha512Hex(data.password).equals(user.getProperty("user_pwd"))) {
				LOG.info("User logged in " + data.username);
				
				return Response.ok(new AuthToken(data.username,(String)user.getProperty("user_role"))).build();
			} else
				LOG.info("Wrong password " + data.username);
				return Response.status(Status.BAD_REQUEST).entity("Wrong password").build();
		} catch (EntityNotFoundException e) {
			LOG.info("User doesn't exist " + data.username);
			return Response.status(Status.BAD_REQUEST).entity("User doesn't exist").build();
		}

	}

}
