package pt.unl.fct.di.apdc.firstwebapp.resources;



import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.EntityNotFoundException;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;

import pt.unl.fct.di.apdc.firstwebapp.util.DeleteData;
import pt.unl.fct.di.apdc.firstwebapp.util.LoginData;

@Path("/delete")
@Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
public class DeleteResource {
	/**
	 * A Logger Object
	 */
	private static final DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();


	public DeleteResource() {
	}

	@DELETE
	@Path("/")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response delete(DeleteData data) {

		try {
			Key userKey = KeyFactory.createKey("User", data.username);
			Entity user = datastore.get(userKey);
			datastore.delete(userKey);
			
			return Response.ok().build();

		} catch (EntityNotFoundException e) {

			return Response.status(Status.BAD_REQUEST).entity("User doesn't exist").build();
		}

	}
	
	@DELETE
	@Path("/gbo")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response deletegbo(DeleteData data) {

		try {
			Key userKey = KeyFactory.createKey("User", data.username);
			Entity user = datastore.get(userKey);
			datastore.delete(userKey);
			
			return Response.ok().build();

		} catch (EntityNotFoundException e) {

			return Response.status(Status.BAD_REQUEST).entity("User doesn't exist").build();
		}

	}

}
