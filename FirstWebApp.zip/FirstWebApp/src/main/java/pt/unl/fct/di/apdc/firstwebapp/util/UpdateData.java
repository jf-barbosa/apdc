package pt.unl.fct.di.apdc.firstwebapp.util;

public class UpdateData {

	public String username;
	public String email;
	public String mobile;
	public String phone;
	public String address;
	public String addressc;
	public String localidade;
	public String cp;
	public String type;
	public String role;
	
	public UpdateData() {}
	
	public UpdateData(String username,String email,String mobile, String role,String phone, String address, String addressc, String localidade, String cp, String type) {
		this.username = username;
		this.email = email;
		this.mobile = mobile;
		this.phone = phone;
		this.address = address;
		this.addressc = addressc;
		this.localidade = localidade;
		this.cp = cp;
		this.type = type;
		this.role = role;
	}
}
