package pt.unl.fct.di.apdc.firstwebapp.util;

public class DeleteData {

	public String username;
	
	public DeleteData() {
		
	}
	
	public DeleteData(String username) {
		this.username = username; 
	}
}
