captureData = function(event) {
    var data = $('form[name="deletegbo"]').jsonify();
    console.log(data);
    $.ajax({
        type: "DELETE",
        url: "https://firstwebapp-236217.appspot.com/rest/delete/gbo",
        contentType: "application/json; charset=utf-8",
        crossDomain: true,
        dataType: 'json',
        success: function(response) {
            if(response) {
                alert("Got token with id: " + response.tokenID);
                // Store token id for later use in localStorage
                localStorage.setItem('tokenID', response.tokenID);
            }
            else {
                alert("No response");
            }
        },
        error: function(response) {
            alert("Error: "+ response.status);
        },
        data: JSON.stringify(data)
    });

    event.preventDefault();
};

window.onload = function() {
    var frms = $('form[name="deletegbo"]');     
    frms[0].onsubmit = captureData;
    
    document.getElementById("login").addEventListener("click",
  	      function() {
  	window.location.href = "https://firstwebapp-236217.appspot.com/restfrontend.html";
  });
}
