captureData = function(event) {
    var data = $('form[name="register"]').jsonify();
    console.log(data);
    $.ajax({
        type: "POST",
        url: "https://firstwebapp-236217.appspot.com/rest/register/GBO",
        contentType: "application/json; charset=utf-8",
        crossDomain: true,
        dataType: 'json',
        success: function(response) {
            if(response) {
                alert("Got token with id: " + response.tokenID);
                // Store token id for later use in localStorage
                localStorage.setItem('tokenID', response.tokenID);
            }
            else {
                alert("No response");
            }
        },
        error: function(response) {
            alert("Error: "+ response.status);
        },
        data: JSON.stringify(data)
    });

    event.preventDefault();
};

window.onload = function() {
    var frms = $('form[name="register"]');     
    frms[0].onsubmit = captureData;
    
    document.getElementById("options").addEventListener("click",
  	      function() {
  	window.location.href = "https://firstwebapp-236217.appspot.com/GBOoptions.html";
  });
}

